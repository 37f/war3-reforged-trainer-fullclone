# v1.0.19 FullClone 迁移：精确作者基线审计

审计日期：2026-09-16（Asia/Shanghai）

## 基线身份

| 项目 | 已验证值 |
| --- | --- |
| Git 分支 | `codex/v1.0.19-fullclone-r12` |
| Git `HEAD` | `4124cd582ed624eeb85d665484755fa8cae65697` |
| 提交标题 | `Restore all native player resource groups and per-player UI operations` |
| 应用版本 | `APP_VERSION = "1.0.19"` |
| Python native helper 协议 | `War3Trainer.NATIVE_HELPER_VERSION = 69` |
| helper DLL SHA-256 | `6161315B505F454476F7D346391EA976F06E3D02E1C15C803DAA9923C4F49DCD` |
| Python | `Python 3.12.10` |

此工作树在审计开始时为干净状态，且没有从协议 23 的通用
`war3-reforged-trainer-1.0.19.zip` 填充。本文档记录的是任务指定的
`4124cd582ed624eeb85d665484755fa8cae65697` 工作树状态。

## 自动化测试

执行环境为 Windows，Capstone 本地依赖通过以下环境变量提供：

```powershell
$env:PYTHONPATH = 'C:\Users\22824\Documents\Codex\2026-08-21\new-chat\.codex-tools\capstone-local'
```

完整作者回归命令：

```powershell
python -m pytest -q --tb=short
```

结果：退出码 1；`679 passed, 976 skipped, 7 errors, 31 subtests passed in 15.26s`。
7 个错误全部在 `test_native_player_resources.py` 的 `native` fixture 建立阶段：
`assert compiler, 'Native resource tests require clang'`。这不是断言到生产
行为后的回归失败，而是 native C 夹具无法编译。

为完整记录当前环境可执行的非 native 回归，未改动任何测试或生产源码，执行：

```powershell
python -m pytest -q --tb=short --ignore=test_native_player_resources.py
```

结果：退出码 0；`679 passed, 976 skipped, 31 subtests passed in 13.90s`。
其中跳过的用例仍是自行检测 `clang` 后跳过的 native C 夹具；本结果只证明
当前机器上可执行的 Python/非 native 覆盖，不替代 native C dispatcher 覆盖。

## Native 测试环境限制

`where.exe clang`、`where.exe clang-cl`、`where.exe cl` 和 `where.exe gcc`
均未找到可执行文件。`shutil.which('clang')` 因而返回 `None`。

本基线的 C 夹具会将 `tools/war3_native_helper.c` 与 Windows harness 一起以
`clang -shared -O2 -Wno-microsoft-goto ... -luser32 -lkernel32` 编译；
`test_native_buff_contract.py` 的夹具还实际包含 `__try/__except`。
控制器已裁决此机没有可用于这些 Windows SEH 夹具的真正 clang。因此 native
夹具在本环境中**受工具链阻塞，未执行**。没有用替代编译器、删除 SEH 路径、
修改 fixture 或将环境错误标作通过来规避该限制。

## 生产文件与运行边界

本任务没有编辑以下生产文件或二进制：

- `war3_reforged_trainer.py`
- `tools/war3_native_helper.c`
- `tools/war3_native_helper.dll`

审计中没有启动 Warcraft III、没有连接游戏进程、没有执行读写、热键、复制、
资源或其他 gameplay 动作。本报告不是游戏内验证。

## 结论与后续关注点

基线来源、版本、协议和 helper 哈希均与任务指定值一致，且可执行的非 native
回归通过。状态为 **DONE_WITH_CONCERNS**：native Windows SEH C-harness 结果
仍需在安装 Microsoft-SEH-capable clang 的环境中，以未经修改的完整命令重新运行。
