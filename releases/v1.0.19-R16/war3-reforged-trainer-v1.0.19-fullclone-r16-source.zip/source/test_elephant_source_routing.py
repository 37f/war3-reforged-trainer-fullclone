import ast
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import war3_reforged_trainer as trainer_module


SOURCE_PATH = Path(__file__).with_name("war3_reforged_trainer.py")


class _Diagnostics:
    latest_path = Path("backup-test.log")

    def __init__(self):
        self.close_calls = 0

    def close(self):
        self.close_calls += 1


class _BackupMemory:
    def __init__(self, pid: int, diagnostics=None, write: bool = False):
        self.pid = pid
        self.write = write
        self.diagnostics = diagnostics or _Diagnostics()
        self.force_refresh = None
        self.closed = False

    def regions(self, force_refresh: bool = False):
        self.force_refresh = force_refresh
        return []

    def close(self):
        self.closed = True

    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc, _traceback):
        self.close()


class ElephantSourceRoutingTests(unittest.TestCase):
    def test_backup_log_archives_are_bounded(self):
        with tempfile.TemporaryDirectory() as directory:
            log_root = Path(directory)
            for index in range(trainer_module.Win10ReadLogger.MAX_ARCHIVE_LOGS + 5):
                (log_root / f"win10-read-20260719-000000-{index:03d}-pid1.log").touch()

            trainer_module.Win10ReadLogger._prune_archives(log_root)

            archives = list(log_root.glob("win10-read-*-pid*.log"))
            self.assertLessEqual(
                len(archives),
                trainer_module.Win10ReadLogger.MAX_ARCHIVE_LOGS - 1,
            )

    def test_normal_source_returns_main_trainer(self):
        main = object.__new__(trainer_module.War3Trainer)
        identity = (0x10, 0x20, 0x30)
        self.assertIs(main.trainer_for_read_source(identity, False), main)

    def test_backup_source_label_uses_same_native_trainer(self):
        main = object.__new__(trainer_module.War3Trainer)
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        main.pid = backup.pid = 123
        identity = (0x10, 0x20, 0x30)
        main._win10_session_trainer = backup
        main._win10_session_identity = identity
        backup._backup_selected_identity = None

        selected = main.trainer_for_read_source(identity, True)

        self.assertIs(selected, main)
        self.assertIsNone(backup._backup_selected_identity)

    def test_backup_source_label_does_not_require_a_backup_session(self):
        main = object.__new__(trainer_module.War3Trainer)
        main.pid = 123
        main._win10_session_trainer = None
        main._win10_session_identity = None
        self.assertIs(main.trainer_for_read_source((0x10, 0x20, 0x30), True), main)

    def test_compatibility_read_propagates_native_failure_without_legacy_setup(self):
        main = object.__new__(trainer_module.War3Trainer)
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        diagnostics = _Diagnostics()
        backup._backup_diagnostics = diagnostics
        main.pid = backup.pid = 123
        main._win10_session_trainer = backup
        main._win10_session_identity = (0x10, 0x20, 0x30)

        with patch.object(main, "read_selected_unit_fields", side_effect=RuntimeError("native unavailable")), patch.object(
            trainer_module, "Win10ReadLogger", side_effect=AssertionError("Legacy log setup"),
        ), patch.object(trainer_module, "Win10ProcessMemory", side_effect=AssertionError("Legacy memory scan")):
            with self.assertRaisesRegex(RuntimeError, "native unavailable"):
                main.read_selected_unit_fields_win10()

        self.assertEqual(diagnostics.close_calls, 0)

    def test_backup_memory_factory_is_disabled(self):
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        backup.pid = 123
        with self.assertRaisesRegex(RuntimeError, "备用读取后端已禁用"):
            backup._process_memory(write=True)

    def test_backup_memory_factory_does_not_reuse_session_diagnostics(self):
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        backup.pid = 123
        with self.assertRaisesRegex(RuntimeError, "备用读取后端已禁用"):
            backup._process_memory()

    def test_compatibility_native_discovery_uses_dll_without_memory_backend(self):
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        with patch.object(backup, "_query_native_table_handlers", return_value={}) as query:
            self.assertEqual(backup._discover_native_handlers_near_table(object(), ("CreateUnit",)), {})
        query.assert_called_once_with(("CreateUnit",))

    def test_compatibility_elephant_handlers_use_same_dll_table_discovery(self):
        backup = object.__new__(trainer_module.BackupReadWar3Trainer)
        handler = trainer_module.NativeHandler("CreateUnit", 0x1000, 0x2000)
        backup._native_handlers = {"CreateUnit": handler}
        pm = object.__new__(trainer_module.Win10ProcessMemory)
        with (
            patch.object(
                trainer_module.War3Trainer,
                "_query_native_table_handlers",
                return_value={"CreateUnit": handler},
            ) as backup_discovery,
            patch.object(
                trainer_module.War3Trainer,
                "_discover_native_handlers_near_table",
                side_effect=AssertionError("ordinary native discovery used"),
            ),
        ):
            handlers = trainer_module.War3Trainer._elephant_handlers(
                backup,
                pm,
                ("CreateUnit",),
            )

        self.assertEqual(handlers, {"CreateUnit": handler})
        backup_discovery.assert_called_once_with(("CreateUnit",))

    def test_batch_gui_reuses_one_edition_session(self):
        source = SOURCE_PATH.read_text(encoding="utf-8")
        self.assertIn('state["elephant_batch_trainer"] = batch_trainer', source)
        self.assertIn(
            'if isinstance(batch_trainer, War3Trainer):',
            source,
        )

    def check_hero_query_without_memory(self, trainer_class, value):
        from test_native_snapshot_binding import make_candidate, make_snapshot
        trainer = trainer_class.__new__(trainer_class)
        candidate = make_candidate(make_snapshot())
        trainer._process_memory = unittest.mock.Mock(side_effect=AssertionError("External memory used"))
        trainer._direct_selected_context = unittest.mock.Mock(return_value=(candidate, candidate.native_snapshot.handle))
        trainer._query_native_table_handlers = unittest.mock.Mock(return_value={
            "GetHeroLevel": trainer_module.NativeHandler("GetHeroLevel", 0, 0x200000)})
        trainer._run_native_helper_ops = unittest.mock.Mock(return_value=[
            trainer_module.NativeHelperOpResult(136, 1), trainer_module.NativeHelperOpResult(77, value)])
        with patch.object(trainer_module, "ProcessMemory", side_effect=AssertionError("Normal memory used")), patch.object(
            trainer_module, "Win10ProcessMemory", side_effect=AssertionError("Backup memory used")
        ):
            self.assertEqual(trainer.get_selected_hero_level(), value)
        trainer._process_memory.assert_not_called()
        trainer._query_native_table_handlers.assert_called_once_with(("GetHeroLevel",))

    def test_inherited_hero_query_uses_native_context_without_memory_factory(self):
        self.check_hero_query_without_memory(trainer_module.BackupReadWar3Trainer, 17)

    def test_normal_hero_query_uses_native_context_without_memory_factory(self):
        self.check_hero_query_without_memory(trainer_module.War3Trainer, 23)

    def test_cached_clone_does_not_reselect_unit(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        handler = trainer_module.NativeHandler("CreateUnit", 0x1000, 0x2000)
        trainer._process_memory = unittest.mock.Mock(side_effect=AssertionError("External memory used"))
        trainer.query_mouse_world_position = unittest.mock.Mock(return_value=(1.0, 2.0))
        trainer._coerce_memory_value = unittest.mock.Mock(return_value=0x68666F6F)
        trainer._elephant_selected_candidate = unittest.mock.Mock(
            side_effect=AssertionError("selected unit was read again")
        )
        trainer._query_native_table_handlers = unittest.mock.Mock(
            return_value={"GetLocalPlayer": handler, "CreateUnit": handler}
        )
        trainer._run_native_helper_ops = unittest.mock.Mock(
            return_value=[trainer_module.NativeHelperOpResult(kind=0, result=0x4444)]
        )

        rawcode, handle = trainer.create_local_unit(
            "hfoo",
            use_selected_lookup=False,
        )

        self.assertEqual((rawcode, handle), (0x68666F6F, 0x4444))
        trainer._elephant_selected_candidate.assert_not_called()
        trainer._query_native_table_handlers.assert_called_once_with(("GetLocalPlayer", "CreateUnit"))
        trainer._process_memory.assert_not_called()

    def test_unit_bound_elephant_gui_functions_do_not_call_main_trainer_directly(self):
        tree = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
        run_gui = next(
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_gui"
        )
        offenders = []
        for function in (
            node
            for node in run_gui.body
            if isinstance(node, ast.FunctionDef)
            and node.name.startswith("elephant_")
            and node.name not in {"elephant_trainer", "elephant_add_resources"}
        ):
            for node in ast.walk(function):
                if (
                    isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "trainer"
                ):
                    offenders.append((function.name, node.lineno))
        self.assertEqual(offenders, [])

    def test_resource_hotkey_uses_main_resource_locator_without_unit_read(self):
        tree = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
        run_gui = next(
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_gui"
        )
        function = next(
            node
            for node in run_gui.body
            if isinstance(node, ast.FunctionDef)
            and node.name == "elephant_add_resources"
        )
        calls = {
            node.func.id
            for node in ast.walk(function)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertIn("trainer", calls)
        self.assertNotIn("elephant_trainer", calls)

    def test_normal_product_elephant_operations_use_live_selection(self):
        source = SOURCE_PATH.read_text(encoding="utf-8")
        self.assertIn('PRODUCT_READ_MODE = "normal"', source)
        self.assertIn("rawcode = None", source)
        self.assertIn("use_selected_lookup=True", source)

    def test_read_buttons_publish_live_selected_summaries_to_candidate_list(self):
        tree = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
        run_gui = next(
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_gui"
        )
        for function_name in ("read_unit", "read_unit_win10"):
            function = next(
                node
                for node in run_gui.body
                if isinstance(node, ast.FunctionDef) and node.name == function_name
            )
            if function_name == "read_unit_win10":
                self.assertEqual(ast.unparse(function.body[0]), "return read_unit()")
                continue
            attribute_calls = {
                node.func.attr
                for node in ast.walk(function)
                if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
            }
            names = {
                node.id
                for node in ast.walk(function)
                if isinstance(node, ast.Name)
            }
            self.assertIn("selected_unit_summaries", attribute_calls)
            self.assertIn("populate_selection_candidates", names)

    def test_single_selection_protocol_remains_separate_from_batch_protocol(self):
        source = SOURCE_PATH.read_text(encoding="utf-8")
        tree = ast.parse(source)
        trainer_class = next(
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == "War3Trainer"
        )
        single = next(
            node
            for node in trainer_class.body
            if isinstance(node, ast.FunctionDef)
            and node.name == "_elephant_selected_handle"
        )
        batch = next(
            node
            for node in trainer_class.body
            if isinstance(node, ast.FunctionDef)
            and node.name == "_elephant_selected_handles"
        )
        self.assertNotIn("GroupRemoveUnit", ast.unparse(single))
        self.assertNotIn("GroupRemoveUnit", ast.unparse(batch))
        self.assertIn("persistent_native_selected_snapshots", ast.unparse(batch))

    def test_hotkeys_do_not_bind_main_trainer(self):
        tree = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
        run_gui = next(
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_gui"
        )
        assignment = next(
            node
            for node in run_gui.body
            if isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == "hotkey_callbacks"
        )
        direct_calls = [
            node.lineno
            for node in ast.walk(assignment)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "trainer"
        ]
        self.assertEqual(direct_calls, [])

    def test_clone_hotkeys_keep_distinct_owner_semantics(self):
        source = SOURCE_PATH.read_text(encoding="utf-8")
        self.assertIn(
            '"clone_to_self": lambda: elephant_create_unit(True, "self"),',
            source,
        )
        self.assertIn(
            '"clone_unit": lambda: elephant_create_unit(True, preserve_owner=True),',
            source,
        )

    def test_mass_clone_preserves_owner_when_panel_override_is_disabled(self):
        source = SOURCE_PATH.read_text(encoding="utf-8")
        function = source[source.index("    def elephant_mass_clone("):
                          source.index("    def elephant_set_hero_attributes(")]
        self.assertIn("use_panel_owner =", function)
        self.assertIn("preserve_owner=not use_panel_owner", function)

    def test_inline_gui_callbacks_do_not_bind_main_trainer(self):
        tree = ast.parse(SOURCE_PATH.read_text(encoding="utf-8"))
        run_gui = next(
            node
            for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "run_gui"
        )
        direct_calls = []
        for statement in run_gui.body:
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            direct_calls.extend(
                node.lineno
                for node in ast.walk(statement)
                if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "trainer"
            )
        self.assertEqual(direct_calls, [])


if __name__ == "__main__":
    unittest.main()
