# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['war3_hotkey_tool.py'],
    pathex=[],
    binaries=[('tools/war3_hotkey_native_helper.dll', 'tools')],
    datas=[('assets/hotkey_icon.ico', 'assets')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='War3ReforgedHotkeys',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='assets/hotkey_icon.ico',
)
