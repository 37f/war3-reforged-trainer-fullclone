from pathlib import Path
from dataclasses import replace
from concurrent.futures import ThreadPoolExecutor
import unittest
import threading
import uuid
from types import SimpleNamespace
from unittest.mock import Mock

import war3_reforged_trainer as trainer_module
from test_native_snapshot_binding import make_snapshot, make_candidate


class _Memory:
    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc, _traceback):
        return None


class NativeHelperRuntimeFeatureTests(unittest.TestCase):
    def make_selection_trainer(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._unit_owner_index = {99: 0x9900}
        trainer._build_unit_object_index = Mock(side_effect=AssertionError("Unexpected global scan"))
        trainer._elephant_selected_handles = Mock(side_effect=AssertionError("Unexpected selection re-query"))
        trainer._selected_candidates_from_selection_manager = Mock(
            side_effect=AssertionError("Unexpected legacy selection")
        )
        trainer._candidate_from_identity = Mock(side_effect=lambda _pm, handle, owner, unit, note, score:
            trainer_module.UnitCandidate(
                base=0, score=score, hp_current_address=0, hp_max_address=0,
                mp_current_address=0, mp_max_address=0, note=note,
                handle=handle, owner_address=owner, unit_address=unit,
            ))
        return trainer

    @staticmethod
    def selection_snapshot(handle=1, unit=0x1000):
        return SimpleNamespace(
            handle=handle, full_handle=handle + 0x100000000,
            owner_address=unit + 0x100, unit_address=unit, type_id=0x68666F6F,
            hp_property=0, mp_property=0,
        )

    def test_empty_native_selection_never_requeries_or_scans_during_reconnect(self):
        for initialized in (False, True):
            for supplied in (False, True):
                with self.subTest(initialized=initialized, supplied=supplied):
                    trainer = self.make_selection_trainer()
                    trainer._persistent_native_initialized = initialized
                    trainer.persistent_native_selected_snapshots = Mock(return_value=())
                    pm = Mock()
                    kwargs = {"persistent_snapshots": ()} if supplied else {}
                    with self.assertRaisesRegex(RuntimeError, "没有稳定"):
                        trainer._selected_candidates_snapshot(pm, **kwargs)
                    self.assertEqual(trainer._unit_owner_index, {99: 0x9900})
                    self.assertEqual(pm.mock_calls, [])
                    self.assertEqual(trainer.persistent_native_selected_snapshots.call_count, 0 if supplied else 1)
                    trainer._build_unit_object_index.assert_not_called()
                    trainer._elephant_selected_handles.assert_not_called()

    def test_changed_native_selection_maps_new_identity_without_global_index(self):
        trainer = self.make_selection_trainer()
        snapshots = (self.selection_snapshot(), self.selection_snapshot(2, 0x2000))
        trainer.persistent_native_selected_snapshots = Mock(side_effect=[(s,) for s in snapshots])
        for snapshot in snapshots:
            selected = trainer._selected_candidates_snapshot(Mock())
            self.assertEqual(len(selected), 1)
            candidate, handle = selected[0]
            self.assertEqual(handle, snapshot.handle)
            self.assertEqual(candidate.handle, snapshot.full_handle)
            self.assertEqual(candidate.unit_address, snapshot.unit_address)
            self.assertEqual(candidate.unit_type_id, snapshot.type_id)
            self.assertEqual(candidate.selection_source, "persistent_native")
        self.assertEqual(trainer.persistent_native_selected_snapshots.call_count, 2)
        trainer._build_unit_object_index.assert_not_called()

    def test_failed_native_group_does_not_publish_partial_identity_index(self):
        for missing in ("handle", "full_handle", "owner_address", "unit_address"):
            with self.subTest(missing=missing):
                trainer = self.make_selection_trainer()
                bad = self.selection_snapshot(2, 0x2000)
                setattr(bad, missing, 0)
                with self.assertRaisesRegex(RuntimeError, "拒绝回退"):
                    trainer._selected_candidates_snapshot(
                        Mock(), persistent_snapshots=(self.selection_snapshot(), bad),
                    )
                self.assertEqual(trainer._unit_owner_index, {99: 0x9900})
                trainer._selected_candidates_from_selection_manager.assert_not_called()

    def test_duplicate_native_identity_cannot_execute_action_twice(self):
        for duplicate in (self.selection_snapshot(), self.selection_snapshot(2), self.selection_snapshot(1, 0x2000)):
            with self.subTest(duplicate=duplicate):
                trainer = self.make_selection_trainer()
                with self.assertRaisesRegex(RuntimeError, "Native selection changed"):
                    trainer._selected_candidates_snapshot(
                        Mock(), persistent_snapshots=(self.selection_snapshot(), duplicate),
                    )
                self.assertEqual(trainer._unit_owner_index, {99: 0x9900})

    def test_stale_native_mapping_cannot_return_partial_group(self):
        for changed in ("handle", "owner_address", "unit_address"):
            with self.subTest(changed=changed):
                trainer = self.make_selection_trainer()
                mapper = trainer._candidate_from_native_snapshot
                first = self.selection_snapshot()
                second = self.selection_snapshot(2, 0x2000)
                good = mapper(None, first)
                bad = mapper(None, second)
                trainer._candidate_from_native_snapshot = Mock(side_effect=[good, replace(bad, **{changed: 0xBAD})])
                with self.assertRaisesRegex(RuntimeError, "Native selection changed"):
                    trainer._selected_candidates_snapshot(Mock(), persistent_snapshots=(first, second))
                self.assertEqual(trainer._unit_owner_index, {99: 0x9900})

    def test_native_selection_overflow_fails_before_mapping(self):
        trainer = self.make_selection_trainer()
        with self.assertRaisesRegex(RuntimeError, "超过安全上限"):
            trainer._selected_candidates_snapshot(
                Mock(), persistent_snapshots=(self.selection_snapshot(),) * 13,
            )
        trainer._candidate_from_identity.assert_not_called()

    def test_partial_native_identity_never_uses_legacy_selection_manager(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._candidate_from_identity = Mock(return_value=None)
        trainer._selected_candidates_from_selection_manager = Mock(
            side_effect=AssertionError("legacy selection fallback must not run")
        )
        pm = Mock()
        snapshot = SimpleNamespace(
            handle=1, full_handle=0, owner_address=0, unit_address=0x1234, type_id=0x41414141
        )
        with self.assertRaisesRegex(RuntimeError, "拒绝回退"):
            trainer._selected_candidates_snapshot(pm, persistent_snapshots=(snapshot,))
        trainer._selected_candidates_from_selection_manager.assert_not_called()

    def test_warm_native_handlers_do_not_read_process_records_again(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        handler = trainer_module.NativeHandler("SetUnitPosition", 0x1000, 0x2000)
        trainer.pid = 123
        trainer._native_handlers = {handler.name: handler}
        trainer._PROCESS_NATIVE_HANDLER_CACHE = {trainer.pid: {handler.name: handler}}
        trainer._persistent_bootstrap_lock = threading.RLock()
        trainer._persistent_native_initialized = True
        pm = Mock()
        self.assertEqual(
            trainer._discover_native_handlers_near_table(pm, (handler.name,)),
            {handler.name: handler},
        )
        self.assertEqual(pm.mock_calls, [])

    def test_prewarm_uses_native_snapshot_without_selection_scan(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._build_unit_object_index = Mock(side_effect=AssertionError("Unexpected global scan"))
        trainer._selected_candidates_from_selection_manager = Mock(
            side_effect=AssertionError("Unexpected legacy selection")
        )
        trainer.persistent_native_init = Mock(return_value=4)
        trainer._discover_native_handlers_near_table = Mock(return_value={
            "SetUnitPosition": trainer_module.NativeHandler("SetUnitPosition", 0, 0x2000),
        })
        trainer._selected_candidates_snapshot = Mock(return_value=[])
        trainer._selected_summaries_from_snapshot = Mock(return_value=())
        trainer._process_memory = Mock(side_effect=AssertionError("External memory"))

        self.assertEqual(trainer.prewarm_elephant_functions(), 4)
        trainer._selected_candidates_snapshot.assert_called_once()
        trainer._selected_summaries_from_snapshot.assert_called_once_with(
            None, [],
        )
        trainer._build_unit_object_index.assert_not_called()
        trainer._selected_candidates_from_selection_manager.assert_not_called()

    def test_persistent_snapshot_has_no_process_scan_dependency(self):
        source = (Path(__file__).parent / "tools" / "war3_native_helper.c").read_text(
            encoding="utf-8"
        )
        start = source.index("static DWORD war3_persistent_selected_snapshot(")
        end = source.index("static DWORD war3_move_selected_group_at_point(", start)
        snapshot = source[start:end]
        for forbidden in ("ReadProcessMemory", "VirtualQuery", "VirtualAlloc", "VirtualProtect"):
            self.assertNotIn(forbidden, snapshot)
        self.assertIn("GroupEnumUnitsSelected", snapshot)
        self.assertIn("war3_validate_unit_identity", snapshot)

    def test_new_session_ignores_shared_heap_records_and_queries_dll(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer.pid = 123
        handler = trainer_module.NativeHandler("SetUnitPosition", 0x1000, 0x2000)
        trainer._native_handlers = {}
        trainer._PROCESS_NATIVE_HANDLER_CACHE = {trainer.pid: {handler.name: handler}}
        trainer._persistent_bootstrap_lock = threading.RLock()
        values = tuple(0x100000 + i*0x100 for i in range(len(trainer.PERSISTENT_NATIVE_NAMES)+3))
        trainer._run_native_helper_ops = Mock(return_value=(trainer_module.NativeHelperOpResult(
            139, len(trainer.PERSISTENT_NATIVE_NAMES), extra_results=values),))
        pm = Mock()
        actual = trainer._discover_native_handlers_near_table(pm, (handler.name,))[handler.name]
        self.assertEqual(actual.record_address, 0)
        self.assertEqual(actual.handler_address, values[trainer.PERSISTENT_NATIVE_NAMES.index(handler.name)+3])
        self.assertEqual(pm.mock_calls, [])
        trainer._run_native_helper_ops.assert_called_once()

    def test_group_move_uses_one_helper_request_without_unit_readback(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer.persistent_native_init = Mock()
        trainer._process_memory = Mock(side_effect=AssertionError("Unexpected external memory context"))
        trainer._native_handlers = {
            "SetUnitPosition": trainer_module.NativeHandler("SetUnitPosition", 0x1000, 0x2000),
        }
        trainer._selected_candidates_snapshot = Mock(side_effect=AssertionError("Unexpected readback"))
        trainer.query_mouse_world_position = Mock(side_effect=AssertionError("Unexpected extra round trip"))
        point = trainer._float_bits(12.5) | (trainer._float_bits(-8) << 32)
        trainer._run_native_helper_ops = Mock(return_value=[trainer_module.NativeHelperOpResult(
            kind=trainer.NATIVE_HELPER_OP_MOVE_SELECTED_GROUP_TO_MOUSE, result=9, arg0=point,
        )])
        self.assertEqual(trainer.move_selected_group_to_mouse(), (9, 12.5, -8.0))
        trainer._process_memory.assert_not_called()
        trainer._run_native_helper_ops.assert_called_once_with(0, ((
            trainer.NATIVE_HELPER_OP_MOVE_SELECTED_GROUP_TO_MOUSE, 0, 0x2000, 0, 0,
        ),))

    def test_reused_native_batch_excludes_other_threads_and_releases_on_error(self):
        # Exercise the real Windows named mutex without attaching to Warcraft
        # or installing a hook. Existing hooks below are only truthy sentinels.
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer.pid = "batch-test-" + uuid.uuid4().hex
        trainer._native_helper_lock = threading.RLock()
        trainer._native_helper_persistent_hook = 1
        trainer._native_helper_persistent_module = 1
        trainer._native_helper_persistent_pid = trainer.pid
        trainer._native_helper_batch_hook = None
        trainer._native_helper_batch_thread_id = None
        mutex_name = f"Local\\War3ReforgedTrainer.NativeHelper.{trainer.pid}"

        def probe_from_other_thread():
            kernel = trainer_module.kernel32
            mutex = kernel.CreateMutexW(None, False, mutex_name)
            self.assertTrue(mutex)
            try:
                status = int(kernel.WaitForSingleObject(mutex, 0))
                if status in (trainer_module.WAIT_OBJECT_0, trainer_module.WAIT_ABANDONED):
                    self.assertTrue(kernel.ReleaseMutex(mutex))
                return status
            finally:
                kernel.CloseHandle(mutex)

        with ThreadPoolExecutor(max_workers=1) as competitor:
            def probe():
                return competitor.submit(probe_from_other_thread).result(timeout=5)

            for fail in (False, True):
                with self.subTest(fail=fail):
                    try:
                        with trainer._native_helper_batch_transaction():
                            self.assertEqual(probe(), trainer_module.WAIT_TIMEOUT)
                            # The command path may skip acquiring the mutex
                            # only while the enclosing batch actually owns it.
                            with trainer._native_helper_transaction():
                                self.assertEqual(probe(), trainer_module.WAIT_TIMEOUT)
                            if fail:
                                raise ValueError("simulated operation failure")
                    except ValueError:
                        if not fail:
                            raise
                    self.assertIsNone(trainer._native_helper_batch_hook)
                    self.assertIsNone(trainer._native_helper_batch_thread_id)
                    self.assertEqual(probe(), trainer_module.WAIT_OBJECT_0)

    def test_native_empty_inventory_needs_neither_properties_nor_external_slots(self):
        from test_native_snapshot_binding import make_snapshot, make_candidate, inventory_result
        trainer = object.__new__(trainer_module.War3Trainer)
        snapshot = replace(make_snapshot(), item_handles=(0,)*6, item_addresses=(0,)*6,
                           item_ids=(0,)*6, item_charges=(0,)*6, item_full_handles=(0,)*6)
        trainer._run_native_helper_ops = Mock(return_value=inventory_result(snapshot, capacity=0))
        trainer._item_objects_from_handles = Mock(side_effect=AssertionError("Unexpected scan"))
        pm = Mock()
        items = trainer._inventory_items_from_candidate(pm, make_candidate(snapshot))
        self.assertEqual(len(items), 6)
        self.assertTrue(all(not item.item_address and not item.native_slot for item in items))
        self.assertEqual(pm.mock_calls, [])
        trainer._item_objects_from_handles.assert_not_called()

    def test_decoder_does_not_treat_instruction_operands_as_calls_or_returns(self):
        pm = Mock()
        pm.read.return_value = bytes.fromhex("448bc3b8e8000000e803000000c3")
        self.assertEqual(trainer_module.War3Trainer._native_function_calls(pm, 0x1000), [0x1010])

    def make_trainer(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._selection_player_candidates = []
        trainer.query_mouse_world_position = Mock(return_value=(12.5, -8.0))
        trainer._process_memory = Mock(return_value=_Memory())
        trainer._elephant_handlers = Mock(
            side_effect=lambda _pm, names: {
                name: trainer_module.NativeHandler(name, 0x1000, 0x2000 + index)
                for index, name in enumerate(names)
            }
        )
        trainer._query_native_table_handlers = Mock(side_effect=lambda names: {
            name: trainer_module.NativeHandler(name, 0, 0x2000 + index)
            for index, name in enumerate(names)})
        return trainer

    def test_selected_clone_uses_single_runtime_clone_transaction(self):
        trainer = self.make_trainer()
        candidate = make_candidate(replace(make_snapshot(), component_mask=4))
        trainer._direct_selected_context = Mock(
            return_value=(candidate, candidate.native_snapshot.handle)
        )
        trainer._run_native_helper_ops = Mock(
            return_value=[trainer_module.NativeHelperOpResult(136, 1),
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_CLONE_SELECTED_UNIT,
                    result=0x7788,
                )
            ] + [trainer_module.NativeHelperOpResult(trainer.NATIVE_HELPER_OP_JASS_MULTI_ARG, 0)] * 13
        )

        rawcode, handle = trainer.create_local_unit(None)

        self.assertEqual((rawcode, handle), (candidate.unit_type_id, 0x7788))
        unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertEqual(unit_handle, candidate.native_snapshot.handle)
        self.assertEqual(len(ops), 15)
        self.assertEqual(
            ops[1][0],
            trainer.NATIVE_HELPER_OP_JASS_CLONE_SELECTED_UNIT,
        )
        self.assertTrue(
            all(
                op[0] == trainer.NATIVE_HELPER_OP_JASS_MULTI_ARG
                for op in ops[2:]
            )
        )

    def test_selected_clone_without_inventory_skips_item_natives(self):
        trainer = self.make_trainer()
        candidate = make_candidate(replace(make_snapshot(), component_mask=4))
        trainer._direct_selected_context = Mock(
            return_value=(candidate, candidate.native_snapshot.handle)
        )
        trainer._selected_components = Mock(return_value={"move": (1, 2)})
        trainer._run_native_helper_ops = Mock(
            return_value=[trainer_module.NativeHelperOpResult(136, 1),
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_CLONE_SELECTED_UNIT,
                    result=0x7788,
                )
            ] + [trainer_module.NativeHelperOpResult(trainer.NATIVE_HELPER_OP_JASS_MULTI_ARG, 0)] * 13
        )

        trainer.create_local_unit(None)

        requested = set(trainer._query_native_table_handlers.call_args.args[0])
        self.assertFalse(
            requested.intersection(trainer.ITEM_FIELD_NATIVE_NAMES)
        )
        _unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertFalse(
            ops[2][1] & trainer.NATIVE_HELPER_CLONE_FLAG_INVENTORY
        )
        for descriptor in ops[9:12]:
            self.assertEqual(descriptor[2:5], (0, 0, 0))
        self.assertEqual(ops[12][2:4], (0, 0))

    def test_selected_clone_with_inventory_requests_item_natives(self):
        trainer = self.make_trainer()
        candidate = make_candidate(replace(make_snapshot(), component_mask=5))
        trainer._direct_selected_context = Mock(
            return_value=(candidate, candidate.native_snapshot.handle)
        )
        trainer._selected_components = Mock(
            return_value={"inventory": (1, 2)}
        )
        trainer._run_native_helper_ops = Mock(
            return_value=[trainer_module.NativeHelperOpResult(136, 1),
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_CLONE_SELECTED_UNIT,
                    result=0x7788,
                )
            ] + [trainer_module.NativeHelperOpResult(trainer.NATIVE_HELPER_OP_JASS_MULTI_ARG, 0)] * 13
        )

        trainer.create_local_unit(None)

        requested = set(trainer._query_native_table_handlers.call_args.args[0])
        self.assertTrue(
            set(trainer.ITEM_FIELD_NATIVE_NAMES).issubset(requested)
        )
        _unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertTrue(
            ops[2][1] & trainer.NATIVE_HELPER_CLONE_FLAG_INVENTORY
        )

    def test_selected_clone_can_preserve_source_owner(self):
        trainer = self.make_trainer()
        candidate = make_candidate(replace(make_snapshot(), component_mask=4))
        trainer._direct_selected_context = Mock(
            return_value=(candidate, candidate.native_snapshot.handle)
        )
        trainer._selected_components = Mock(return_value={})
        trainer._run_native_helper_ops = Mock(
            return_value=[trainer_module.NativeHelperOpResult(136, 1),
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_CLONE_SELECTED_UNIT,
                    result=0x7788,
                )
            ] + [trainer_module.NativeHelperOpResult(trainer.NATIVE_HELPER_OP_JASS_MULTI_ARG, 0)] * 13
        )

        trainer.create_local_unit(None, preserve_owner=True)

        requested = set(trainer._query_native_table_handlers.call_args.args[0])
        self.assertIn("GetOwningPlayer", requested)
        self.assertNotIn("GetLocalPlayer", requested)
        _unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertTrue(
            ops[2][1] & trainer.NATIVE_HELPER_CLONE_FLAG_PRESERVE_OWNER
        )

    def test_explicit_create_keeps_plain_create_path(self):
        trainer = self.make_trainer()
        trainer._coerce_memory_value = Mock(return_value=0x68666F6F)
        trainer._elephant_selected_candidate = Mock()
        trainer._direct_selected_context = Mock()
        trainer._run_native_helper_ops = Mock(
            return_value=[
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_CREATE_LOCAL_UNIT,
                    result=0x7788,
                )
            ]
        )

        trainer.create_local_unit("hfoo")

        unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertEqual(unit_handle, 0)
        self.assertEqual(len(ops), 1)
        self.assertEqual(
            ops[0][0],
            trainer.NATIVE_HELPER_OP_JASS_CREATE_LOCAL_UNIT,
        )
        trainer._elephant_selected_candidate.assert_not_called()
        trainer._direct_selected_context.assert_not_called()

    def test_health_lock_heals_local_units_without_invulnerability(self):
        trainer = self.make_trainer()
        trainer._run_native_helper_ops = Mock(
            return_value=[
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_HEAL_LOCAL_UNITS,
                    result=3,
                )
            ]
        )

        self.assertEqual(trainer.heal_local_player_units(), 3)

        unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertEqual(unit_handle, 0)
        self.assertEqual(ops[0][0], trainer.NATIVE_HELPER_OP_JASS_HEAL_LOCAL_UNITS)
        requested_names = trainer._elephant_handlers.call_args.args[1]
        self.assertNotIn("SetUnitInvulnerable", requested_names)
        self.assertIn("SetWidgetLife", requested_names)

    def test_reset_allied_cooldowns_uses_one_game_thread_enumeration(self):
        trainer = self.make_trainer()
        trainer._run_native_helper_ops = Mock(
            return_value=[
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_JASS_RESET_LOCAL_COOLDOWNS,
                    result=7,
                )
            ]
        )

        self.assertEqual(trainer.reset_local_player_unit_cooldowns(), 7)

        unit_handle, ops = trainer._run_native_helper_ops.call_args.args[:2]
        self.assertEqual(unit_handle, 0)
        self.assertEqual(
            ops[0][0],
            trainer.NATIVE_HELPER_OP_JASS_RESET_LOCAL_COOLDOWNS,
        )
        requested_names = trainer._elephant_handlers.call_args.args[1]
        self.assertIn("GroupEnumUnitsOfPlayer", requested_names)
        self.assertIn("UnitResetCooldown", requested_names)
        self.assertEqual(len(ops), 3)

    def test_python_and_c_helper_protocol_versions_match(self):
        helper_source = (
            Path(__file__).with_name("tools") / "war3_native_helper.c"
        ).read_text(encoding="utf-8")
        self.assertIn(
            f"#define WAR3_NATIVE_VERSION {trainer_module.War3Trainer.NATIVE_HELPER_VERSION}u",
            helper_source,
        )
        self.assertIn("WAR3_NATIVE_OP_JASS_HEAL_LOCAL_UNITS 117u", helper_source)
        self.assertIn("WAR3_NATIVE_OP_JASS_CLONE_SELECTED_UNIT 118u", helper_source)
        self.assertIn("WAR3_NATIVE_OP_JASS_SELECTED_UNITS 119u", helper_source)
        self.assertIn(
            "WAR3_NATIVE_OP_JASS_RESET_LOCAL_COOLDOWNS 121u",
            helper_source,
        )
        self.assertIn("WAR3_NATIVE_OP_PERSISTENT_REGISTER_NATIVE 130u", helper_source)
        self.assertIn(
            "WAR3_NATIVE_OP_PERSISTENT_SELECTED_SNAPSHOT 131u",
            helper_source,
        )
        self.assertIn("uint64_t selected_units[12]", helper_source)
        self.assertIn("while (selected_count < 12u)", helper_source)
        self.assertIn("selected_units[selected_count++] = current;", helper_source)
        self.assertIn("while (processed < 100000u)", helper_source)
        self.assertIn("remove_unit(target)", helper_source)
        self.assertIn("if (target_value != source_value)", helper_source)
        self.assertIn(
            "if (clone_flags & WAR3_CLONE_FLAG_INVENTORY)",
            helper_source,
        )
        self.assertIn(
            "clone_flags & WAR3_CLONE_FLAG_PRESERVE_OWNER",
            helper_source,
        )
        self.assertIn(
            "get_integer(target_item, integer_fields[index])",
            helper_source,
        )

    def test_persistent_snapshot_parser_preserves_native_payload(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._persistent_native_initialized = True
        trainer._persistent_bootstrap_lock = threading.RLock()
        row = [0] * trainer.PERSISTENT_NATIVE_SNAPSHOT_QWORDS
        row[:17] = [
            0x101,
            0x202,
            0x303,
            2,
            0x68666F6F,
            0x3F800000,
            0x40000000,
            0x40400000,
            0x40800000,
            0x40A00000,
            0x40C00000,
            0x40E00000,
            5,
            1234,
            11,
            22,
            33,
        ]
        row[17:23] = [0x49303031, 0, 0, 0, 0, 0]
        row[23:29] = [3, 0, 0, 0, 0, 0]
        row[29:35] = [0x505, 0, 0, 0, 0, 0]
        row[35:41] = [0x606, 0, 0, 0, 0, 0]
        row[41] = 2
        row[42:44] = [0x41420031, 0x41420032]
        row[90:92] = [1, 3]
        row[138:140] = [0x123400005678, 0x707]
        trainer._run_native_helper_ops = Mock(
            return_value=[
                trainer_module.NativeHelperOpResult(
                    kind=trainer.NATIVE_HELPER_OP_PERSISTENT_SELECTED_SNAPSHOT,
                    result=1,
                    extra_results=tuple(row),
                )
            ]
        )

        snapshots = trainer.persistent_native_selected_snapshots()

        self.assertEqual(len(snapshots), 1)
        snapshot = snapshots[0]
        self.assertEqual((snapshot.handle, snapshot.unit_address), (0x101, 0x202))
        self.assertEqual((snapshot.hp, snapshot.hp_max), (1.0, 2.0))
        self.assertEqual((snapshot.mp, snapshot.mp_max), (3.0, 4.0))
        self.assertEqual(snapshot.item_ids, (0x49303031, 0, 0, 0, 0, 0))
        self.assertEqual(snapshot.item_charges[0], 3)
        self.assertEqual(snapshot.item_handles[0], 0x505)
        self.assertEqual(snapshot.item_addresses[0], 0x606)
        self.assertEqual(snapshot.full_handle, 0x123400005678)
        self.assertEqual(snapshot.owner_address, 0x707)
        self.assertEqual(snapshot.ability_ids, (0x41420031, 0x41420032))
        self.assertEqual(snapshot.ability_levels, (1, 3))

    def test_persistent_snapshot_parser_rejects_truncated_ability_payload(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._persistent_bootstrap_lock = threading.RLock()
        trainer._persistent_native_initialized = True
        row = [0] * trainer.PERSISTENT_NATIVE_SNAPSHOT_QWORDS
        row[41] = 49
        trainer._run_native_helper_ops = Mock(return_value=[
            trainer_module.NativeHelperOpResult(
                kind=trainer.NATIVE_HELPER_OP_PERSISTENT_SELECTED_SNAPSHOT,
                result=1,
                extra_results=tuple(row),
            )
        ])
        with self.assertRaisesRegex(RuntimeError, "技能扩展结果长度异常"):
            trainer.persistent_native_selected_snapshots()

    def test_persistent_snapshot_parser_decodes_extended_ability_pairs(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._persistent_bootstrap_lock = threading.RLock()
        trainer._persistent_native_initialized = True
        row = [0] * trainer.PERSISTENT_NATIVE_SNAPSHOT_QWORDS
        row[41] = 50
        row[42:90] = list(range(1, 49))
        row[90:138] = list(range(101, 149))
        row[138:140] = [0x123400005678, 0x707]
        extended = row + [0x41420049, 49, 0x41420050, 50]
        trainer._run_native_helper_ops = Mock(return_value=[
            trainer_module.NativeHelperOpResult(
                kind=trainer.NATIVE_HELPER_OP_PERSISTENT_SELECTED_SNAPSHOT,
                result=1,
                extra_results=tuple(extended),
            )
        ])
        snapshot = trainer.persistent_native_selected_snapshots()[0]
        self.assertEqual(len(snapshot.ability_ids), 50)
        self.assertEqual(snapshot.ability_ids[-2:], (0x41420049, 0x41420050))
        self.assertEqual(snapshot.ability_levels[-2:], (49, 50))

    def test_elephant_handlers_discovers_every_requested_native(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._native_handlers = {}
        requested = ("CreateUnit", "BlzGetItemIntegerField")

        def discover(names):
            self.assertEqual(tuple(names), requested)
            trainer._native_handlers.update(
                {
                    name: trainer_module.NativeHandler(name, 0x1000, 0x2000 + index)
                    for index, name in enumerate(requested)
                }
            )
            return trainer._native_handlers

        trainer._query_native_table_handlers = Mock(side_effect=discover)

        handlers = trainer._elephant_handlers(object(), requested)

        self.assertEqual(set(handlers), set(requested))
        trainer._query_native_table_handlers.assert_called_once_with(requested)

    def test_elephant_handlers_reports_missing_native_without_key_error(self):
        trainer = object.__new__(trainer_module.War3Trainer)
        trainer._native_handlers = {}
        trainer._query_native_table_handlers = Mock(return_value={})

        with self.assertRaisesRegex(
            RuntimeError,
            "缺少 native 函数：BlzGetItemIntegerField",
        ):
            trainer._elephant_handlers(object(), ("BlzGetItemIntegerField",))

    def test_selected_handles_uses_deduplicated_helper_extra_results(self):
        trainer = self.make_trainer()
        trainer.persistent_native_selected_snapshots = Mock(
            return_value=tuple(SimpleNamespace(handle=value) for value in (0x100, 0x200, 0x100, 0x300))
        )

        handles = trainer._elephant_selected_handles(object())

        self.assertEqual(handles, (0x100, 0x200, 0x300))
        trainer.persistent_native_selected_snapshots.assert_called_once()

    def test_selected_handles_rejects_more_than_twelve(self):
        trainer = self.make_trainer()
        trainer.persistent_native_selected_snapshots = Mock(
            return_value=tuple(SimpleNamespace(handle=value) for value in range(1, 14))
        )

        with self.assertRaisesRegex(RuntimeError, "超过安全上限"):
            trainer._elephant_selected_handles(object())

    def test_batch_selected_units_isolates_failure_and_restores_override(self):
        trainer = self.make_trainer()
        candidates = [
            Mock(unit_address=0x1000, unit_type_id=0x68666F6F),
            Mock(unit_address=0x2000, unit_type_id=0x686D696C),
            Mock(unit_address=0x3000, unit_type_id=0x686D7072),
        ]
        trainer._selected_candidates_snapshot = Mock(
            return_value=list(zip(candidates, (0x11, 0x22, 0x33)))
        )
        trainer._elephant_selection_override = None
        visited = []

        def action():
            candidate, handle = trainer._elephant_selection_override
            visited.append((candidate.unit_address, handle))
            if handle == 0x22:
                raise RuntimeError("unsupported")
            return handle

        succeeded, failed, results, errors = trainer.run_for_selected_units(action)

        self.assertEqual((succeeded, failed), (2, 1))
        self.assertEqual(results, (0x11, 0x33))
        self.assertEqual(visited, [(0x1000, 0x11), (0x2000, 0x22), (0x3000, 0x33)])
        self.assertIn("unsupported", errors[0])
        self.assertIsNone(trainer._elephant_selection_override)


if __name__ == "__main__":
    unittest.main()
