# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['war3_reforged_trainer.py'],
    pathex=[],
    binaries=[
        ('tools/war3_native_helper.dll', 'tools'),
        ('tools/capstone.dll', 'capstone/lib'),
    ],
    datas=[('assets/app_icon.png', 'assets')],
    hiddenimports=['capstone', 'war3_runtime_check'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='War3ReforgedTrainer-v1.0.19-FullClone-R16',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    uac_admin=True,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='assets/app_icon.ico',
    version='tools/war3_version_info.txt',
)
